
from flask import Flask, render_template, request, redirect, url_for
import os
from ultralytics import YOLO
import uuid
import cv2

UPLOAD_FOLDER = 'static/uploads'

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Load the trained YOLOv8 model
model = YOLO('yolov8/best.pt')  # Replace with your own model if needed

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    if 'image' not in request.files:
        return redirect(request.url)
    file = request.files['image']
    if file.filename == '':
        return redirect(request.url)

    filename = str(uuid.uuid4()) + ".jpg"
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(filepath)

    # Run YOLO detection
    results = model(filepath)[0]

    # Draw results
    annotated_frame = results.plot()
    annotated_path = os.path.join(app.config['UPLOAD_FOLDER'], f"annotated_{filename}")
    cv2.imwrite(annotated_path, annotated_frame)

    return render_template("result.html", original=filename, annotated=f"annotated_{filename}")

if __name__ == "__main__":
    app.run(debug=True)
