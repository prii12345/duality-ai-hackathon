from flask import Flask, render_template, request, redirect, url_for, send_from_directory, session
from ultralytics import YOLO
import os
import shutil
from datetime import datetime
from werkzeug.utils import secure_filename
import glob

app = Flask(__name__)
# A secret key is required for Flask sessions to store temporary data.
app.secret_key = 'a_secure_and_random_string'

# Define the absolute paths for the upload and predict folders.
app.config['UPLOAD_FOLDER'] = os.path.join('static', 'uploads')
app.config['PREDICT_FOLDER'] = os.path.join('static', 'predict')

# Load the YOLO model, handling potential errors if the file is not found
try:
    # This assumes 'best.pt' is in a 'yolov8' subdirectory within your project.
    model = YOLO("yolov8/best.pt")
except Exception as e:
    model = None
    print(f"Error loading model: {e}")

# Ensure the necessary directories exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['PREDICT_FOLDER'], exist_ok=True)

@app.route('/', methods=['GET', 'POST'])
def index():
    """
    Renders the main page and handles image detection on POST request.
    This combines the welcome and upload logic into a single page.
    """
    error = None

    if request.method == 'POST':
        if not model:
            error = "Object detection model not loaded."
            return render_template('index.html', error=error)

        file = request.files.get('image')
        if not file or file.filename == '':
            error = "No image selected."
            return render_template('index.html', error=error)
        
        filename = secure_filename(file.filename)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Create a unique filename for the uploaded image to prevent conflicts
        unique_filename = f"{timestamp}_{filename}"
        save_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
        file.save(save_path)

        conf = float(request.form.get("conf", 0.25))

        # Run the prediction. YOLO will save the annotated image to a new directory
        # named with the timestamp inside the PREDICT_FOLDER.
        try:
            results = model.predict(source=save_path, conf=conf, save=True, project=app.config['PREDICT_FOLDER'], name=timestamp, exist_ok=True)
            
            # Use glob to reliably find the annotated image file.
            prediction_output_dir = os.path.join(app.config['PREDICT_FOLDER'], timestamp)
            image_files = glob.glob(os.path.join(prediction_output_dir, '*'))
            
            image_url = None
            download_filename = None
            summary = {}
            if image_files:
                annotated_path = image_files[0]
                relative_path = os.path.relpath(annotated_path, 'static')
                
                image_url = url_for('static', filename=relative_path.replace('\\', '/'))
                download_filename = relative_path.replace('\\', '/')

                detected_classes = [model.names[int(cls)] for cls in results[0].boxes.cls]
                summary = {obj: detected_classes.count(obj) for obj in set(detected_classes)}

            # Store the result data in a Flask session to pass it to the result page.
            session['result'] = {
                'image_url': image_url,
                'download_filename': download_filename,
                'summary': summary
            }
            return redirect(url_for('result'))
        except Exception as e:
            error = f"An error occurred during detection: {e}"
            return render_template('index.html', error=error)

    return render_template('index.html')

@app.route('/result')
def result():
    """
    Displays the detection results stored in the session.
    """
    # Use session.pop() to retrieve the results and clear the session data
    # for a one-time display.
    result_data = session.pop('result', None)
    if not result_data:
        return redirect(url_for('index'))
    
    return render_template('result.html', **result_data)

@app.route('/download/<path:filename>')
def download(filename):
    """
    Allows the user to download the detected image file.
    """
    # The filename is a path relative to the static folder
    return send_from_directory("static", filename, as_attachment=True)

@app.route('/history')
def history():
    """
    Displays the history of all past detections.
    """
    history_data = []
    # Get a list of all prediction folders, sorted by timestamp
    folders = sorted([d for d in os.listdir(app.config['PREDICT_FOLDER']) if os.path.isdir(os.path.join(app.config['PREDICT_FOLDER'], d))], reverse=True)
    
    for folder in folders:
        folder_path = os.path.join(app.config['PREDICT_FOLDER'], folder)
        image_files = glob.glob(os.path.join(folder_path, '*'))
        
        if image_files:
            image_file = image_files[0]
            relative_path = os.path.relpath(image_file, 'static')

            try:
                display_time = datetime.strptime(folder, "%Y%m%d_%H%M%S").strftime("%Y-%m-%d %H:%M:%S")
            except ValueError:
                display_time = folder

            history_data.append({
                "img": url_for('static', filename=relative_path.replace('\\', '/')),
                "download": relative_path.replace('\\', '/'),
                "name": os.path.basename(image_file),
                "time": display_time
            })
    return render_template('history.html', history_data=history_data)

@app.route('/clear_history', methods=['POST'])
def clear_history():
    """
    Clears all history by deleting the predict folder.
    """
    shutil.rmtree(app.config['PREDICT_FOLDER'], ignore_errors=True)
    os.makedirs(app.config['PREDICT_FOLDER'], exist_ok=True)
    return redirect(url_for('history'))


@app.route('/game')
def game():
    return render_template('game.html')


if __name__ == '__main__':
    app.run(debug=True)
